<?php $__env->startSection('title', 'Lead Details'); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="card card-primary">
        <!-- form start -->
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(Session::get('error')); ?>

            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('leads.update', $lead->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card-body p-0">
                <div class="bs-stepper">
                    <div class="bs-stepper-header" role="tablist">
                        <!-- your steps here -->
                        <div class="step" data-target="#part-1">
                            <button type="button" class="step-trigger" role="tab" aria-controls="part-1" id="part-1-trigger">
                                <span class="bs-stepper-circle">1</span>
                                <span class="bs-stepper-label">Data Match & Land Registry</span>
                            </button>
                        </div>
                        <div class="line"></div>
                        <div class="step" data-target="#part-2">
                            <button type="button" class="step-trigger" role="tab" aria-controls="part-2" id="part-2-trigger">
                                <span class="bs-stepper-circle">2</span>
                                <span class="bs-stepper-label">Lead Status</span>
                            </button>
                        </div>
                        <div class="line"></div>
                        <div class="step" data-target="#part-3">
                            <button type="button" class="step-trigger" role="tab" aria-controls="part-3" id="part-3-trigger">
                                <span class="bs-stepper-circle">3</span>
                                <span class="bs-stepper-label">Retrofit Assessment / Findings</span>
                            </button>
                        </div>
                        <div class="line"></div>
                        <div class="step" data-target="#part-4">
                            <button type="button" class="step-trigger" role="tab" aria-controls="part-4" id="part-4-trigger">
                                <span class="bs-stepper-circle">4</span>
                                <span class="bs-stepper-label">Measures to install</span>
                            </button>
                        </div>
                        <div class="line"></div>
                        <div class="step" data-target="#part-5">
                            <button type="button" class="step-trigger" role="tab" aria-controls="part-5" id="part-5-trigger">
                                <span class="bs-stepper-circle">5</span>
                                <span class="bs-stepper-label">Additional Costs</span>
                            </button>
                        </div>
                        <div class="line"></div>
                        <div class="step" data-target="#part-6">
                            <button type="button" class="step-trigger" role="tab" aria-controls="part-6" id="part-6-trigger">
                                <span class="bs-stepper-circle">6</span>
                                <span class="bs-stepper-label">Summary</span>
                            </button>
                        </div>
                    </div>
                    <div class="bs-stepper-content">
                        <!-- PART 1 -->
                        <div id="part-1" class="content" role="tabpanel" aria-labelledby="part-1-trigger">
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="land_reg_check">Land Registry Check</label>
                                        <select class="form-control <?php $__errorArgs = ['land_reg_check'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="land_reg_check" name="land_reg_check" style="width: 100%;">
                                            <option value="Downloaded" <?php echo e(isset($row) && $row->land_reg_check == 'Downloaded' ? 'selected' : (old('land_reg_check') == 'Downloaded' ? 'selected': '')); ?>>Downloaded</option>
                                            <option value="Not Available" <?php echo e(isset($row) && $row->land_reg_check == 'Not Available' ? 'selected' : (old('land_reg_check') == 'Not Available' ? 'selected': '')); ?>>Not Available</option>
                                        </select>
                                        <?php $__errorArgs = ['land_reg_check'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="land_reg_check" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="land_reg_matched">Land Registry Matched</label>
                                        <select class="form-control <?php $__errorArgs = ['land_reg_matched'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="land_reg_matched" name="land_reg_matched" style="width: 100%;">
                                            <option value="true" <?php echo e(isset($row) && $row->land_reg_matched ? 'selected' : (old('land_reg_matched') ? 'selected': '')); ?>>Yes</option>
                                            <option value="false" <?php echo e(isset($row) && !$row->land_reg_matched ? 'selected' : (old('land_reg_matched') == 'false' ? 'selected': '')); ?>>No</option>
                                        </select>
                                        <?php $__errorArgs = ['land_reg_matched'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="land_reg_matched" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="is_match_sent">Data Match Request Sent</label>
                                        <select class="form-control <?php $__errorArgs = ['is_match_sent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_match_sent" name="is_match_sent" style="width: 100%;">
                                            <option value="true" <?php echo e(isset($row) && $row->is_match_sent ? 'selected' : (old('is_match_sent') ? 'selected': '')); ?>>Yes</option>
                                            <option value="false" <?php echo e(isset($row) && !$row->is_match_sent ? 'selected' : (old('is_match_sent') == 'false' ? 'selected': '')); ?>>No</option>
                                        </select>
                                        <?php $__errorArgs = ['is_match_sent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="is_match_sent" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="data_match_result">Data Match Result</label>
                                        <select class="form-control <?php $__errorArgs = ['data_match_result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_match_result" name="data_match_result" style="width: 100%;">
                                            <option value="Awaiting" <?php echo e(isset($row) && $row->data_match_result == 'Awaiting' ? 'selected' : (old('data_match_result') == 'Awaiting' ? 'selected': '')); ?>>Awaiting</option>
                                            <option value="Matched" <?php echo e(isset($row) && $row->data_match_result == 'Matched' ? 'selected' : (old('data_match_result') == 'Matched' ? 'selected': '')); ?>>Matched</option>
                                            <option value="Unmatched" <?php echo e(isset($row) && $row->data_match_result == 'Unmatched' ? 'selected' : (old('data_match_result') == 'Unmatched' ? 'selected': '')); ?>>Unmatched</option>
                                            <option value="Unverified" <?php echo e(isset($row) && $row->data_match_result == 'Unverified' ? 'selected' : (old('data_match_result') == 'Unverified' ? 'selected': '')); ?>>Unverified</option>
                                        </select>
                                        <?php $__errorArgs = ['data_match_result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="data_match_result" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-primary" onclick="stepper.next()" style="">Next</button>
                        </div>
                        <!-- PART 2 -->
                        <div id="part-2" class="content" role="tabpanel" aria-labelledby="part-2-trigger">
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="status">Lead Status</label>
                                        <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status" style="width: 100%;">
                                            <option value="Approved" <?php echo e(isset($row) && $row->status == 'Approved' ? 'selected' : (old('status') == 'Approved' ? 'selected': '')); ?>>Approved</option>
                                            <option value="Rejected" <?php echo e(isset($row) && $row->status == 'Rejected' ? 'selected' : (old('status') == 'Rejected' ? 'selected': '')); ?>>Rejected</option>
                                            <option value="On Hold" <?php echo e(isset($row) && $row->status == 'On Hold' ? 'selected' : (old('status') == 'On Hold' ? 'selected': '')); ?>>On Hold</option>
                                        </select>
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="status" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Comments</label>
                                        <textarea class="form-control <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="comment" rows="4" placeholder="Enter Comments" name="comment"><?php echo e(isset($row) ? $row->comment : old('comment')); ?></textarea>
                                        <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="comment" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-primary" onclick="stepper.previous()">Previous</button>
                            <button type="button" class="btn btn-primary next_btn" onclick="stepper.next()" style="">Next</button>
                            <button type="submit" class="btn btn-primary submit_btn" style="display: none">Submit</button>
                        </div>
                        <!-- PART 3 -->
                        <div id="part-3" class="content" role="tabpanel" aria-labelledby="part-3-trigger">

                            <button type="button" class="btn btn-primary" onclick="stepper.previous()">Previous</button>
                            <button type="button" class="btn btn-primary" onclick="stepper.next()" style="">Next</button>
                        </div>
                        <!-- PART 4 -->
                        <div id="part-4" class="content" role="tabpanel" aria-labelledby="part-4-trigger">
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('Non Condensing Boiler Replacement')" name="is_boiler_replacement" type="checkbox" id="is_boiler_replacement" <?php echo e(old('is_boiler_replacement') == 'true' ? 'checked' : (isset($row) && $row->is_boiler_replacement ? 'checked' : '')); ?>>
                                            <label for="is_boiler_replacement" class="custom-control-label">Non Condensing Boiler Replacement</label>
                                            <?php $__errorArgs = ['is_boiler_replacement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_boiler_replacement" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('External wall insulation')" name="is_external_wall_insulation" type="checkbox" id="is_external_wall_insulation" <?php echo e(old('is_external_wall_insulation') == 'true' ? 'checked' : (isset($row) && $row->is_external_wall_insulation ? 'checked' : '')); ?>>
                                            <label for="is_external_wall_insulation" class="custom-control-label">External wall insulation</label>
                                            <?php $__errorArgs = ['is_external_wall_insulation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_external_wall_insulation" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('First Time Central Heating')" name="is_first_time_central_heating" type="checkbox" id="is_first_time_central_heating" <?php echo e(old('is_first_time_central_heating') == 'true' ? 'checked' : (isset($row) && $row->is_first_time_central_heating ? 'checked' : '')); ?>>
                                            <label for="is_first_time_central_heating" class="custom-control-label">First Time Central Heating</label>
                                            <?php $__errorArgs = ['is_first_time_central_heating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_first_time_central_heating" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('Internal wall insulation')" name="is_internal_wall_insulation" type="checkbox" id="is_internal_wall_insulation" <?php echo e(old('is_internal_wall_insulation') == 'true' ? 'checked' : (isset($row) && $row->is_internal_wall_insulation ? 'checked' : '')); ?>>
                                            <label for="is_internal_wall_insulation" class="custom-control-label">Internal wall insulation</label>
                                            <?php $__errorArgs = ['is_internal_wall_insulation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_internal_wall_insulation" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('Cavity Wall insulation')" name="is_cavity_wall_insulation" type="checkbox" id="is_cavity_wall_insulation" <?php echo e(old('is_cavity_wall_insulation') == 'true' ? 'checked' : (isset($row) && $row->is_cavity_wall_insulation ? 'checked' : '')); ?>>
                                            <label for="is_cavity_wall_insulation" class="custom-control-label">Cavity Wall insulation</label>
                                            <?php $__errorArgs = ['is_cavity_wall_insulation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_cavity_wall_insulation" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('Under Floor insulation')" name="is_under_floor_insulation" type="checkbox" id="is_under_floor_insulation" <?php echo e(old('is_under_floor_insulation') == 'true' ? 'checked' : (isset($row) && $row->is_under_floor_insulation ? 'checked' : '')); ?>>
                                            <label for="is_under_floor_insulation" class="custom-control-label">Under Floor insulation</label>
                                            <?php $__errorArgs = ['is_under_floor_insulation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_under_floor_insulation" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('Loft insulation')" name="is_loft_insulation" type="checkbox" id="is_loft_insulation" <?php echo e(old('is_loft_insulation') == 'true' ? 'checked' : (isset($row) && $row->is_under_floor_insulation ? 'checked' : '')); ?>>
                                            <label for="is_loft_insulation" class="custom-control-label">Loft insulation</label>
                                            <?php $__errorArgs = ['is_loft_insulation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_loft_insulation" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('Heating controls')" name="is_heating_controls" type="checkbox" id="is_heating_controls" <?php echo e(old('is_heating_controls') == 'true' ? 'checked' : (isset($row) && $row->is_heating_controls ? 'checked' : '')); ?>>
                                            <label for="is_heating_controls" class="custom-control-label">Heating controls</label>
                                            <?php $__errorArgs = ['is_heating_controls'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_heating_controls" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('Solar PV')" name="is_solar_pv" type="checkbox" id="is_solar_pv" <?php echo e(old('is_solar_pv') == 'true' ? 'checked' : (isset($row) && $row->is_solar_pv ? 'checked' : '')); ?>>
                                            <label for="is_solar_pv" class="custom-control-label">Solar PV</label>
                                            <?php $__errorArgs = ['is_solar_pv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_solar_pv" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('Air Source Heat pump')" name="is_air_source" type="checkbox" id="is_air_source" <?php echo e(old('is_air_source') == 'true' ? 'checked' : (isset($row) && $row->is_air_source ? 'checked' : '')); ?>>
                                            <label for="is_air_source" class="custom-control-label">Air Source Heat pump</label>
                                            <?php $__errorArgs = ['is_air_source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_air_source" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('Storage Heater')" name="is_storage_heater" type="checkbox" id="is_storage_heater" <?php echo e(old('is_storage_heater') == 'true' ? 'checked' : (isset($row) && $row->is_storage_heater ? 'checked' : '')); ?>>
                                            <label for="is_storage_heater" class="custom-control-label">Storage Heater</label>
                                            <?php $__errorArgs = ['is_storage_heater'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_storage_heater" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input class="custom-control-input" onchange="addMeasureForm('RIR')" name="is_rir" type="checkbox" id="is_rir" <?php echo e(old('is_rir') == 'true' ? 'checked' : (isset($row) && $row->is_rir ? 'checked' : '')); ?>>
                                            <label for="is_rir" class="custom-control-label">RIR</label>
                                            <?php $__errorArgs = ['is_rir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span id="is_rir" class="error invalid-feedback"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php if(isset($row)): ?>
                                <?php $__currentLoopData = $row->measure_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $measure_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="measure-type">
                                        <div class="row">
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label for="m2">M2</label>
                                                    <input value="<?php echo e(old('m2', $measure_type->m2)); ?>" type="text" class="form-control <?php $__errorArgs = ['m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="m2" id="m2" placeholder="Enter M2">
                                                    <?php $__errorArgs = ['m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span id="m2" class="error invalid-feedback"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label for="installer_id">Select Installer</label>
                                                    <select class="form-control select2 <?php $__errorArgs = ['installer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="installer_id" style="width: 100%;">
                                                        <option disabled selected value> -- select installer -- </option>
                                                        <?php $__currentLoopData = $installers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($installer->id); ?>" <?php echo e($measure_type->installer_id == $installer->id ? 'selected' : (old('installer_id') == $installer->id ? 'selected': '')); ?>>
                                                                <?php echo e($installer->first_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['installer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span id="installer_id" class="error invalid-feedback"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label for="cost">Installer Cost</label>
                                                    <input value="<?php echo e(old('cost', $measure_type->cost)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cost" id="cost" placeholder="Enter Installer Cost">
                                                    <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span id="cost" class="error invalid-feedback"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label for="material_cost">Material Cost</label>
                                                    <input value="<?php echo e(old('material_cost', $measure_type->material_cost)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['material_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="material_cost" id="material_cost" placeholder="Enter Material Cost">
                                                    <?php $__errorArgs = ['material_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span id="material_cost" class="error invalid-feedback"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label for="start_date">Install Start Date</label>
                                                    <input value="<?php echo e(old('start_date', $measure_type->start_date)); ?>" type="date" class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="start_date" id="start_date" placeholder="Enter Install Start Date">
                                                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span id="start_date" class="error invalid-feedback"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label for="completion_date">Install Completion Date</label>
                                                    <input value="<?php echo e(old('completion_date', $measure_type->completion_date)); ?>" type="date" class="form-control <?php $__errorArgs = ['completion_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="completion_date" id="completion_date" placeholder="Enter Install Completion Date">
                                                    <?php $__errorArgs = ['completion_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span id="completion_date" class="error invalid-feedback"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label for="is_warranty_applied">Warranties Applied</label>
                                                    <select class="form-control <?php $__errorArgs = ['is_warranty_applied'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_warranty_applied" name="is_warranty_applied" style="width: 100%;">
                                                        <option value="true" <?php echo e($measure_type->is_warranty_applied == 'true' ? 'selected' : (old('is_warranty_applied') == 'true' ? 'selected': '')); ?>>Yes</option>
                                                        <option value="false" <?php echo e($measure_type->is_warranty_applied == 'false' ? 'selected' : (old('is_warranty_applied') == 'false' ? 'selected': '')); ?>>No</option>
                                                    </select>
                                                    <?php $__errorArgs = ['is_warranty_applied'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span id="is_warranty_applied" class="error invalid-feedback"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label for="ibg_cost">IBG Cost</label>
                                                    <input value="<?php echo e(old('ibg_cost', $measure_type->ibg_cost)); ?>" type="number" min="0" class="ibg_cost form-control <?php $__errorArgs = ['ibg_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ibg_cost" id="ibg_cost" placeholder="Enter IBG Cost">
                                                    <?php $__errorArgs = ['ibg_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span id="ibg_cost" class="error invalid-feedback"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-4 d-flex justify-content-center align-items-center mt-2">
                                                <button type="button" class="btn btn-primary mx-2" onclick="addType()"><i class="fas fa-plus-square"></i></button>
                                                <button type="button" class="btn btn-danger mx-2 remove_type"><i class="fas fa-trash"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>
                                <div id="measure-type"></div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="total_material">Total Material Cost</label>
                                        <input value="0" type="number" min="0" readonly class="form-control" id="total_material" name="total_material">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="total_installer">Total Installer Cost</label>
                                        <input value="0" type="number" min="0" readonly class="form-control" id="total_installer" name="total_installer">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="sub_total">Sub Total</label>
                                        <input value="0" type="number" min="0" readonly class="form-control" id="sub_total" name="sub_total">
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-primary" onclick="stepper.previous()">Previous</button>
                            <button type="button" class="btn btn-primary" onclick="stepper.next()">Next</button>
                        </div>
                        <!-- PART 5 -->
                        <div id="part-5" class="content" role="tabpanel" aria-labelledby="part-5-trigger">
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="trickle_vents">Trickle Vents</label>
                                        <input value="<?php echo e(old('trickle_vents', 0)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['trickle_vents'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="trickle_vents" id="trickle_vents" placeholder="Enter Trickle Vents">
                                        <?php $__errorArgs = ['trickle_vents'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="trickle_vents" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="air_brick">Air Brick</label>
                                        <input value="<?php echo e(old('air_brick', 0)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['air_brick'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="air_brick" id="air_brick" placeholder="Enter Air Brick">
                                        <?php $__errorArgs = ['air_brick'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="air_brick" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="fans">Fans</label>
                                        <input value="<?php echo e(old('fans', 0)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['fans'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fans" id="fans" placeholder="Enter Fans">
                                        <?php $__errorArgs = ['fans'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="fans" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="minor_work_cert">Minor Works Cert</label>
                                        <input value="<?php echo e(old('minor_work_cert', 0)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['minor_work_cert'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="minor_work_cert" id="minor_work_cert" placeholder="Enter Minor Works Cert">
                                        <?php $__errorArgs = ['minor_work_cert'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="minor_work_cert" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="roof_vents">Roof Vents</label>
                                        <input value="<?php echo e(old('roof_vents', 0)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['roof_vents'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="roof_vents" id="roof_vents" placeholder="Enter Roof Vents">
                                        <?php $__errorArgs = ['roof_vents'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="roof_vents" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="door_undercut">Door Undercut</label>
                                        <input value="<?php echo e(old('door_undercut', 0)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['door_undercut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="door_undercut" id="door_undercut" placeholder="Enter Door Undercut">
                                        <?php $__errorArgs = ['door_undercut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="door_undercut" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="other_ventilation">Other Ventilation</label>
                                        <input value="<?php echo e(old('other_ventilation', 0)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['other_ventilation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="other_ventilation" id="other_ventilation" placeholder="Enter Other Ventilation">
                                        <?php $__errorArgs = ['other_ventilation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="other_ventilation" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="retrofit_coordinator_cost">Retrofit Coordinator Cost</label>
                                        <input value="<?php echo e(old('retrofit_coordinator_cost', 0)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['retrofit_coordinator_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="retrofit_coordinator_cost" id="retrofit_coordinator_cost" placeholder="Enter Retrofit Coordinator Cost">
                                        <?php $__errorArgs = ['retrofit_coordinator_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="retrofit_coordinator_cost" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="retrofit_assessor_cost">Retrofit Assessor Cost</label>
                                        <input value="<?php echo e(old('retrofit_assessor_cost', 0)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['retrofit_assessor_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="retrofit_assessor_cost" id="retrofit_assessor_cost" placeholder="Enter Retrofit Assessor Cost">
                                        <?php $__errorArgs = ['retrofit_assessor_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="retrofit_assessor_cost" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="gas_safe_reg">Gas Safe-CPS-land Reg</label>
                                        <input value="<?php echo e(old('gas_safe_reg', 0)); ?>" type="number" min="0" class="form-control <?php $__errorArgs = ['gas_safe_reg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gas_safe_reg" id="gas_safe_reg" placeholder="Enter Gas Safe-CPS-land Reg">
                                        <?php $__errorArgs = ['gas_safe_reg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="gas_safe_reg" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="handover_on">Handover Date</label>
                                        <input value="<?php echo e(old('handover_on')); ?>" type="date" class="form-control <?php $__errorArgs = ['handover_on'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="handover_on" id="handover_on" placeholder="Enter Handover date">
                                        <?php $__errorArgs = ['handover_on'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="handover_on" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label for="status">Funder Paper Work</label>
                                        <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status" style="width: 100%;">
                                            <option value="" <?php echo e(isset($row) && $row->is_completed_submission ? 'selected' : (old('is_completed_submission') == 'true' ? 'selected': '')); ?>>N/A</option>
                                            <option value="true" <?php echo e(isset($row) && $row->is_completed_submission ? 'selected' : (old('is_completed_submission') == 'true' ? 'selected': '')); ?>>Pending</option>
                                            <option value="false" <?php echo e(isset($row) && !$row->is_completed_submission ? 'selected' : (old('is_completed_submission') == 'false' ? 'selected': '')); ?>>Submitted</option>
                                            <option value="false" <?php echo e(isset($row) && !$row->is_completed_submission ? 'selected' : (old('is_completed_submission') == 'false' ? 'selected': '')); ?>>Error</option>
                                            <option value="false" <?php echo e(isset($row) && !$row->is_completed_submission ? 'selected' : (old('is_completed_submission') == 'false' ? 'selected': '')); ?>>Accepted</option>
                                        </select>
                                        <?php $__errorArgs = ['is_completed_submission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span id="is_completed_submission" class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-primary" onclick="stepper.previous()">Previous</button>
                            <button type="button" class="btn btn-primary" onclick="summary_calculate()" style="">Next</button>
                        </div>
                        <!-- PART 6 -->
                        <div id="part-6" class="content" role="tabpanel" aria-labelledby="part-6-trigger">
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="funding">Funding</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">£</span>
                                            </div>
                                            <input value="0" type="number" disabled class="form-control" id="funding_summary">
                                            <div class="input-group-append">
                                                <span class="input-group-text">.00</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="total_cost">Total Cost of Job</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">£</span>
                                            </div>
                                            <input value="0" type="number" name="total_cost" readonly class="form-control" id="total_cost">
                                            <div class="input-group-append">
                                                <span class="input-group-text">.00</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="gross_profit">Gross Profit</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">£</span>
                                            </div>
                                            <input value="0" type="number" readonly class="form-control" name="gross_profit" id="gross_profit">
                                            <div class="input-group-append">
                                                <span class="input-group-text">.00</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="introducer_share">Introducer Share</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">%</span>
                                            </div>
                                            <input value="0" type="number" name="introducer_share" min="0" max="100" class="form-control" id="introducer_share">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="introducer_fee">Introducer Fee Payable</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">£</span>
                                            </div>
                                            <input value="0" type="number" readonly class="form-control" name="introducer_fee" id="introducer_fee">
                                            <div class="input-group-append">
                                                <span class="input-group-text">.00</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="net_profit">Net Profit</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">£</span>
                                            </div>
                                            <input value="0" type="number" readonly class="form-control" name="net_profit" id="net_profit">
                                            <div class="input-group-append">
                                                <span class="input-group-text">.00</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-primary" onclick="stepper.previous()">Previous</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- /.card -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('plugins/bs-stepper/js/bs-stepper.min.js')); ?>"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            window.stepper = new Stepper(document.querySelector('.bs-stepper'))
        })
        function fundingCal() {
            const score = $("#abs_score").val();
            const rate = $("#rate").val();
            const funding = score * rate;
            $('#funding').attr('value', funding);
            $('#funding_summary').attr('value', funding);
        }
        function summary_calculate() {
            const funding = parseInt($("#funding").val());
            const sub_total = parseInt($("#sub_total").val());
            const trickle_vents = parseInt($("#trickle_vents").val());
            const air_brick = parseInt($("#air_brick").val());
            const fans = parseInt($("#fans").val());
            const minor_work_cert = parseInt($("#minor_work_cert").val());
            const roof_vents = parseInt($("#roof_vents").val());
            const door_undercut = parseInt($("#door_undercut").val());
            const other_ventilation = parseInt($("#other_ventilation").val());
            const gas_safe_reg = parseInt($("#gas_safe_reg").val());
            const retrofit_coordinator_cost = parseInt($("#retrofit_coordinator_cost").val());
            const retrofit_assessor_cost = parseInt($("#retrofit_assessor_cost").val());
            let total_ibg_cost = 0;
            $(".ibg_cost").each(function() {
                total_ibg_cost += parseFloat(this.value);
            });

            const total_cost = sub_total + trickle_vents + air_brick + fans + minor_work_cert + roof_vents + door_undercut + other_ventilation + gas_safe_reg + retrofit_assessor_cost + retrofit_coordinator_cost + total_ibg_cost;
            const gross_profit = total_cost - funding;
            $('#total_cost').attr('value', total_cost);
            $('#gross_profit').attr('value', gross_profit);
            $('#net_profit').attr('value', gross_profit);
            stepper.next();
        }
        let form_index = 0;
        let material_index = [];
        let installer_index = [];
        function addMaterial(id) {
            material_index[`${id}`]++;
            $("#" + id + " .materials:last").after(`<div class="row materials">
    <div class="col-5">
        <div class="form-group">
            <label for="material_name">Material</label>
            <input value="<?php echo e(old('material_name')); ?>" type="text" class="form-control <?php $__errorArgs = ['material_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][materials][${material_index[id]}][title]" id="material_name" placeholder="Enter Material Name">
            <?php $__errorArgs = ['material_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span id="material_name" class="error invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-5">
            <div class="form-group">
                <label for="material_cost">Material Cost</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">£</span>
                    </div>
                    <input value="<?php echo e(old('material_cost', 0)); ?>" type="number" min="0" class="form-control m-cost <?php $__errorArgs = ['material_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][materials][${material_index[id]}][cost]" id="material_cost" placeholder="Enter Material Cost">
                <?php $__errorArgs = ['material_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span id="material_cost" class="error invalid-feedback"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="input-group-append">
                <span class="input-group-text">.00</span>
            </div>
        </div>
    </div>
</div>
<div class="col-2 d-flex justify-content-center align-items-center mt-2">
    <button type="button" class="btn btn-danger mx-2 remove_material"><i class="fas fa-trash"></i></button>
</div>
</div>`);
        }
        function addInstaller(id) {
            installer_index[`${id}`]++;
            $("#" + id + " .installers:last").after(`<div class="row installers">
    <div class="col-5">
        <div class="form-group">
            <label for="title">Installer</label>
            <input value="<?php echo e(old('title')); ?>" type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][installers][${installer_index[id]}][title]" id="installer_title" placeholder="Enter Installer">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span id="title" class="error invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-5">
            <div class="form-group">
                <label for="cost">Installer Cost</label>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">£</span>
                    </div>
                    <input value="<?php echo e(old('cost', 0)); ?>" type="number" min="0" class="form-control i-cost <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][installers][${installer_index[id]}][cost]" id="installer_cost" placeholder="Enter Installer Cost">
                <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span id="cost" class="error invalid-feedback"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="input-group-append">
                <span class="input-group-text">.00</span>
            </div>
        </div>
    </div>
</div>
<div class="col-2 d-flex justify-content-center align-items-center mt-2">
    <button type="button" class="btn btn-danger mx-2 remove_installer"><i class="fas fa-trash"></i></button>
</div>
</div>`);
        }
        function convertToSlug(Text) {
            return Text.toLowerCase()
                .replace(/ /g, "-")
                .replace(/[^\w-]+/g, "");
        }

        function addMeasureForm(type) {
            const slug = convertToSlug(type);
            material_index[`${slug}`] = 0;
            installer_index[`${slug}`] = 0;
            form_index = $("#measure-type .card-outline").length;
            if ($('#' + slug).length) {
                $('#' + slug).remove()
                form_index--
            } else {
                $("#measure-type").append(`<div class="card-outline card-primary" id="${slug}">
    <div class="card-header">
        <div class="row">
            <div class="col-6 m-auto">
                <h3 class="card-title">${type}</h3>
            </div>
            <div class="col-6">
                <div class="form-group m-auto">
                    <select class="form-control <?php $__errorArgs = ['types[${form_index}][measure_status]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][measure_status]" style="width: 100%;">
                        <option value="Awaiting Installation" <?php echo e(old('measure_status') == 'Awaiting Installation' ? 'selected': ''); ?>>Awaiting Installation</option>
                        <option value="Booked" <?php echo e(old('measure_status') == 'Booked' ? 'selected': ''); ?>>Booked</option>
                        <option value="Started" <?php echo e(old('measure_status') == 'Started' ? 'selected': ''); ?>>Started</option>
                        <option value="Completed" <?php echo e(old('measure_status') == 'Completed' ? 'selected': ''); ?>>Completed</option>
                    </select>
                    <?php $__errorArgs = ['types[${form_index}][measure_status]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="types[${form_index}][measure_status]" class="error invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

        </div>
    </div>
    <div class="card-body">
        <input type="hidden" name="types[${form_index}][category]" value="${type}" />
        <div class="row">
            <div class="col-3 m-auto">
                <div class="form-group">
                    <div class="custom-control custom-checkbox">
                        <input class="custom-control-input" name="types[${form_index}][is_pibi]" type="checkbox" id="is_pibi" <?php echo e(old('is_pibi') == 'true' ? 'checked' : (isset($row) && $row->is_pibi ? 'checked' : '')); ?>>
                        <label for="is_pibi" class="custom-control-label">PIBI</label>
                        <?php $__errorArgs = ['is_pibi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="is_pibi" class="error invalid-feedback"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="col-3 m-auto">
            <div class="form-group">
                <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" name="types[${form_index}][is_design]" type="checkbox" id="is_design" <?php echo e(old('is_design') == 'true' ? 'checked' : (isset($row) && $row->is_design ? 'checked' : '')); ?>>
                        <label for="is_design" class="custom-control-label">Design</label>
                        <?php $__errorArgs = ['is_design'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="is_design" class="error invalid-feedback"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="col-3 m-auto">
            <div class="form-group">
                <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" name="types[${form_index}][is_tech_survey]" type="checkbox" id="is_tech_survey" <?php echo e(old('is_tech_survey') == 'true' ? 'checked' : (isset($row) && $row->is_under_floor_insulation ? 'checked' : '')); ?>>
                        <label for="is_tech_survey" class="custom-control-label">Tech Survey</label>
                        <?php $__errorArgs = ['is_tech_survey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="is_tech_survey" class="error invalid-feedback"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="form-group">
                <label for="is_customer_informed">Customer Informed of Start</label>
                <select class="form-control <?php $__errorArgs = ['is_customer_informed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_customer_informed" name="is_customer_informed" style="width: 100%;">
                        <option value="true" <?php echo e(isset($row) && $row->is_customer_informed ? 'selected' : (old('is_customer_informed') ? 'selected': '')); ?>>Yes</option>
                        <option value="false" <?php echo e(isset($row) && !$row->is_customer_informed ? 'selected' : (old('is_customer_informed') == 'false' ? 'selected': '')); ?>>No</option>
                    </select>
                    <?php $__errorArgs = ['is_customer_informed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="is_customer_informed" class="error invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <div class="form-group">
                    <label for="m2">M2</label>
                    <input value="<?php echo e(old('m2')); ?>" type="text" class="form-control <?php $__errorArgs = ['m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][m2]" id="m2" placeholder="Enter M2">
                    <?php $__errorArgs = ['m2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="m2" class="error invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label for="installer_id">Select Installer</label>
                    <select class="form-control select2 <?php $__errorArgs = ['installer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][installer_id]" style="width: 100%;">
                        <option disabled selected value> -- select installer -- </option>
                        <?php $__currentLoopData = $installers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($installer->id); ?>" <?php echo e(old('installer_id') == $installer->id ? 'selected': ''); ?>>
                            <?php echo e($installer->first_name); ?>

                </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
<?php $__errorArgs = ['installer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="installer_id" class="error invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label for="start_date">Install Start Date</label>
                    <input value="<?php echo e(old('start_date')); ?>" type="date" class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][start_date]" id="start_date" placeholder="Enter Install Start Date">
                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="start_date" class="error invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <div class="form-group">
                    <label for="completion_date">Install Completion Date</label>
                    <input value="<?php echo e(old('completion_date')); ?>" type="date" class="form-control <?php $__errorArgs = ['completion_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][completion_date]" id="completion_date" placeholder="Enter Install Completion Date">
                    <?php $__errorArgs = ['completion_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="completion_date" class="error invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label for="is_warranty_applied">Warranties Applied</label>
                    <select class="form-control <?php $__errorArgs = ['is_warranty_applied'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_warranty_applied" name="types[${form_index}][is_warranty_applied]" style="width: 100%;">
                        <option value="true" <?php echo e(old('is_warranty_applied') == 'true' ? 'selected': ''); ?>>Yes</option>
                        <option value="false" <?php echo e(old('is_warranty_applied') == 'false' ? 'selected': ''); ?>>No</option>
                    </select>
                    <?php $__errorArgs = ['is_warranty_applied'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="is_warranty_applied" class="error invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label for="ibg_cost">IBG Cost</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">£</span>
                        </div>
                        <input value="<?php echo e(old('ibg_cost', 0)); ?>" type="number" min="0" class="form-control ibg_cost <?php $__errorArgs = ['ibg_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][ibg_cost]" id="ibg_cost" placeholder="Enter IBG Cost">
                        <?php $__errorArgs = ['ibg_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="ibg_cost" class="error invalid-feedback"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-group-append">
                    <span class="input-group-text">.00</span>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row materials">
    <div class="col-5">
        <div class="form-group">
            <label for="title">Material</label>
            <input value="<?php echo e(old('title')); ?>" type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name=" types[${form_index}][materials][${material_index[`${slug}`]}][title]" id="material_title" placeholder="Enter Material Name">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="title" class="error invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-5">
                <div class="form-group">
                    <label for="cost">Material Cost</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">£</span>
                        </div>
                        <input value="<?php echo e(old('cost', 0)); ?>" type="number" min="0" class="form-control m-cost <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][materials][${material_index[`${slug}`]}][cost]" id="material_cost" placeholder="Enter Material Cost">
                        <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="cost" class="error invalid-feedback"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-group-append">
                    <span class="input-group-text">.00</span>
                </div>
            </div>
        </div>
    </div>
    <div class="col-2 d-flex justify-content-center align-items-center mt-2">
        <button type="button" class="btn btn-primary mx-2" onclick="addMaterial('${slug}')"><i class="fas fa-plus-square"></i></button>
            </div>
        </div>
        <div class="row installers">
            <div class="col-5">
                <div class="form-group">
                    <label for="title">Installer</label>
                    <input value="<?php echo e(old('title')); ?>" type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][installers][${installer_index[`${slug}`]}][title]" id="installer_title" placeholder="Enter Installer">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="title" class="error invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-5">
                <div class="form-group">
                    <label for="cost">Installer Cost</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">£</span>
                        </div>
                        <input value="<?php echo e(old('cost', 0)); ?>" type="number" min="0" class="form-control i-cost <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="types[${form_index}][installers][${installer_index[`${slug}`]}][cost]" id="installer_cost" placeholder="Enter Installer Cost">
                        <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span id="cost" class="error invalid-feedback"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-group-append">
                    <span class="input-group-text">.00</span>
                </div>
            </div>
        </div>
    </div>
    <div class="col-2 d-flex justify-content-center align-items-center mt-2">
        <button type="button" class="btn btn-primary mx-2" onclick="addInstaller('${slug}')"><i class="fas fa-plus-square"></i></button>
            </div>
        </div>
    </div>
</div>`)
            }
        }

        $(document).on('click', '.remove_material', function () {
            $(this).parents('div.materials').remove();
        });
        $(document).on('click', '.remove_installer', function () {
            $(this).parents('div.installers').remove();
        });
        $(document).ready(function ($) {
            $("#status").on('change', function () {
                const flex_check = $(this).val()
                if (flex_check != 'Approved') {
                    $(".next_btn").hide()
                    $(".submit_btn").show()
                } else {
                    $(".next_btn").show()
                    $(".submit_btn").hide()
                }
            }).change();
            $("#introducer_share").on('change', function () {
                const value = $(this).val()
                const gross_profit = parseInt($("#gross_profit").val());
                const fee = (((value / 100) * gross_profit)).toFixed(2);
                $('#introducer_fee').attr('value', fee);
                $('#net_profit').attr('value', (gross_profit - fee).toFixed(2));
            }).change();
            $('body').on('input', '.m-cost', function() {
                var m_price = 0;
                $('.m-cost').each(function(index, el) {
                    const price = parseInt($(el).val());
                    m_price = m_price+price
                });
                $('#total_material').val(m_price)
                const total_installer = parseInt($("#total_installer").val());
                $('#sub_total').val(m_price + total_installer)
            });
            $('body').on('input', '.i-cost', function() {
                var i_price = 0;
                $('.i-cost').each(function(index, el) {
                    const price = parseInt($(el).val());
                    i_price = i_price+price
                });
                $('#total_installer').val(i_price)
                const total_material = parseInt($("#total_material").val());
                $('#sub_total').val(i_price + total_material)
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('plugins/bs-stepper/css/bs-stepper.min.css')); ?>">
    <style>
        .bs-stepper-label {
            font-size: 14px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Leads-app-laravel\resources\views/leads/lead-details.blade.php ENDPATH**/ ?>