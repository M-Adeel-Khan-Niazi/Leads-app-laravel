<?php $__env->startSection('title', 'Funders'); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-3">
                            <h3 class="card-title py-2">Funders List</h3>
                        </div>
                        <div class="col-md-2 offset-7">
                            <a href="<?php echo e(route('funders.create')); ?>" class="btn btn-block btn-outline-primary">Create</a>
                        </div>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $funders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $funder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($funder->first_name); ?></td>
                            <td><?php echo e($funder->last_name ?? 'N/A'); ?></td>
                            <td><?php echo e($funder->email); ?></td>
                            <td><?php echo e($funder->address); ?></td>
                            <td><?php echo e($funder->created_at->format('Y-m-d H:i')); ?></td>
                            <td>
                                <form method="post" id="delete-form" action="<?php echo e(route('funders.destroy', $funder->id)); ?>">
                                    <a href="<?php echo e(route('funders.edit', $funder->id)); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-pen"></i></a>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="SingleDelete btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr style="width: 100%">No Records Found!</tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
                <div class="card-footer clearfix ">
                    <?php echo e($funders->links('pagination.links')); ?>

                </div>
            </div>
            <!-- /.card -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Leads-app-laravel\resources\views/funders/index.blade.php ENDPATH**/ ?>