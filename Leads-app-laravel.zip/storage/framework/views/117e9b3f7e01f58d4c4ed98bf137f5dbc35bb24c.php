<?php $__env->startSection('title', 'Data Match & Land Registry'); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="card card-primary">
        <!-- form start -->
        <form method="POST" action="<?php echo e(route('leads.data_matched', request('lead')->id)); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="land_reg_check">Land Registry Check</label>
                            <select class="form-control <?php $__errorArgs = ['land_reg_check'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="land_reg_check" name="land_reg_check" style="width: 100%;">
                                <option value="Downloaded" <?php echo e(isset($row) && $row->land_reg_check == 'Downloaded' ? 'selected' : (old('land_reg_check') == 'Downloaded' ? 'selected': '')); ?>>Downloaded</option>
                                <option value="Not Available" <?php echo e(isset($row) && $row->land_reg_check == 'Not Available' ? 'selected' : (old('land_reg_check') == 'Not Available' ? 'selected': '')); ?>>Not Available</option>
                            </select>
                            <?php $__errorArgs = ['land_reg_check'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="land_reg_check" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="is_land_reg_matched">Land Registry Matched</label>
                            <select class="form-control <?php $__errorArgs = ['is_land_reg_matched'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_land_reg_matched" name="is_land_reg_matched" style="width: 100%;">
                                <option value="" <?php echo e(isset($row) && $row->is_land_reg_matched == null ? 'selected' : (old('is_land_reg_matched') ? 'selected': '')); ?>>N/A</option>
                                <option value="true" <?php echo e(isset($row) && $row->is_land_reg_matched ? 'selected' : (old('is_land_reg_matched') ? 'selected': '')); ?>>Yes</option>
                                <option value="false" <?php echo e(isset($row) && !$row->is_land_reg_matched ? 'selected' : (old('is_land_reg_matched') == 'false' ? 'selected': '')); ?>>No</option>
                            </select>
                            <?php $__errorArgs = ['is_land_reg_matched'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="is_land_reg_matched" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="is_match_sent">Data Match Request Sent</label>
                            <select class="form-control <?php $__errorArgs = ['is_match_sent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_match_sent" name="is_match_sent" style="width: 100%;">
                                <option value="" <?php echo e(isset($row) && $row->is_match_sent == null ? 'selected' : (old('land_reg_matched') ? 'selected': '')); ?>>N/A</option>
                                <option value="true" <?php echo e(isset($row) && $row->is_match_sent ? 'selected' : (old('is_match_sent') ? 'selected': '')); ?>>Yes</option>
                                <option value="false" <?php echo e(isset($row) && !$row->is_match_sent ? 'selected' : (old('is_match_sent') == 'false' ? 'selected': '')); ?>>No</option>
                            </select>
                            <?php $__errorArgs = ['is_match_sent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="is_match_sent" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="data_match_result">Data Match Result</label>
                            <select class="form-control <?php $__errorArgs = ['data_match_result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="data_match_result" name="data_match_result" style="width: 100%;">
                                <option value="Awaiting" <?php echo e(isset($row) && $row->data_match_result == 'Awaiting' ? 'selected' : (old('data_match_result') == 'Awaiting' ? 'selected': '')); ?>>Awaiting</option>
                                <option value="Matched" <?php echo e(isset($row) && $row->data_match_result == 'Matched' ? 'selected' : (old('data_match_result') == 'Matched' ? 'selected': '')); ?>>Matched</option>
                                <option value="Unmatched" <?php echo e(isset($row) && $row->data_match_result == 'Unmatched' ? 'selected' : (old('data_match_result') == 'Unmatched' ? 'selected': '')); ?>>Unmatched</option>
                                <option value="Unverified" <?php echo e(isset($row) && $row->data_match_result == 'Unverified' ? 'selected' : (old('data_match_result') == 'Unverified' ? 'selected': '')); ?>>Unverified</option>
                            </select>
                            <?php $__errorArgs = ['data_match_result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="data_match_result" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="status">Lead Status</label>
                            <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status" style="width: 100%;">
                                <option value="approved" <?php echo e(isset($row) && $row->status == 'approved' ? 'selected' : (old('status') == 'approved' ? 'selected': '')); ?>>Approved</option>
                                <option value="rejected" <?php echo e(isset($row) && $row->status == 'rejected' ? 'selected' : (old('status') == 'rejected' ? 'selected': '')); ?>>Rejected</option>
                                <option value="onHold" <?php echo e(isset($row) && $row->status == 'onHold' ? 'selected' : (old('status') == 'onHold' ? 'selected': '')); ?>>On Hold</option>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="status" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label>Comments</label>
                            <textarea class="form-control <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="comment" rows="4" placeholder="Enter Comments" name="comment"><?php echo e(isset($row) ? $row->comment : old('comment')); ?></textarea>
                            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="comment" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
                <a href="<?php echo e(route('leads.index')); ?>" class="btn btn-secondary">Back</a>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
    <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Leads-app-laravel\resources\views/leads/data-matched-form.blade.php ENDPATH**/ ?>