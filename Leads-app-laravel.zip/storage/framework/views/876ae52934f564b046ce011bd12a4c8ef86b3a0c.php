<?php $__env->startSection('title', 'Leads'); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <form action="<?php echo e(route('leads.index')); ?>">
                        <div class="row">
                            <div class="col-md-3">
                                <h3 class="card-title py-2">Leads List</h3>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <select class="form-control" name="status" id="featured">
                                        <option <?php echo e(is_null(request()->input('status')) ? 'selected' : ''); ?> value=""> All</option>
                                        <option <?php echo e(request()->input('status') == 'pending' ? 'selected' : ''); ?> value="pending">Lead Submitted</option>
                                        <option <?php echo e(request()->input('status') == 'rejected' ? 'selected' : ''); ?> value="rejected">Lead Rejected</option>
                                        <option <?php echo e(request()->input('status') == 'onHold' ? 'selected' : ''); ?> value="onHold">Lead On Hold</option>
                                        <option <?php echo e(request()->input('status') == 'approved' ? 'selected' : ''); ?> value="approved">Lead Approved</option>
                                        <option <?php echo e(request()->input('status') == 'Awaiting' ? 'selected' : ''); ?> value="Awaiting">Awaiting Data Matched</option>
                                        <option <?php echo e(request()->input('status') == 'Matched' ? 'selected' : ''); ?> value="Matched">Data Matched Sent</option>
                                        <option <?php echo e(request()->input('status') == 'Unverified' ? 'selected' : ''); ?> value="Unverified">Data Matched Un-Verified</option>
                                        <option <?php echo e(request()->input('status') == 'Unmatched' ? 'selected' : ''); ?> value="Unmatched">Data Un-Matched</option>
                                        <option <?php echo e(request()->input('status') == 'raBooked' ? 'selected' : ''); ?> value="raBooked">RA Booked</option>
                                        <option <?php echo e(request()->input('status') == 'raCompleted' ? 'selected' : ''); ?> value="raCompleted">RA Completed</option>
                                        <option <?php echo e(request()->input('status') == 'raLodged' ? 'selected' : ''); ?> value="raLodged">RA Lodged</option>
                                        <option <?php echo e(request()->input('status') == 'installationBooked' ? 'selected' : ''); ?> value="installationBooked">Installation Booked</option>
                                        <option <?php echo e(request()->input('status') == 'installationStarted' ? 'selected' : ''); ?> value="installationStarted">Installation Started</option>
                                        <option <?php echo e(request()->input('status') == 'installationCompleted' ? 'selected' : ''); ?> value="installationCompleted">Installation Completed</option>
                                        <option <?php echo e(request()->input('status') == 'installationCompleted' ? 'selected' : ''); ?> value="installationCompleted">Hanover Pending</option>
                                        <option <?php echo e(request()->input('status') == 'hanoverCompleted' ? 'selected' : ''); ?> value="hanoverCompleted">Hanover Completed</option>
                                        <option <?php echo e(request()->input('status') == 'paperworkSubmitted' ? 'selected' : ''); ?> value="paperworkSubmitted">Funder Paperwork Submitted</option>
                                        <option <?php echo e(request()->input('status') == 'paperworkError' ? 'selected' : ''); ?> value="paperworkError">Funder Paperwork Error</option>
                                        <option <?php echo e(request()->input('status') == 'paperworkAccepted' ? 'selected' : ''); ?> value="paperworkAccepted">Funder Paperwork Accepted</option>
                                        <option <?php echo e(request()->input('status') == 'invoicePaid' ? 'selected' : ''); ?> value="invoicePaid">Invoice Paid</option>
                                        <?php if(request()->user()->role == 'admin'): ?>
                                            <option <?php echo e(request()->input('status') == 'invoicePaid' ? 'selected' : ''); ?> value="invoicePaid">Agent Awaiting Invoice</option>
                                            <option <?php echo e(request()->input('status') == 'agentPaid' ? 'selected' : ''); ?> value="agentPaid">Agent Paid</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <input value="<?php echo e(request()->search ?? old('search')); ?>" type="text" class="form-control" name="search" placeholder="Enter Search">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
                            </div>
                            <div class="col-md-2">
                                <a href="<?php echo e(route('leads.create')); ?>" class="btn btn-block btn-outline-primary">Create</a>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>Agent Name</th>
                            <th>Address</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($lead->agent_details ? $lead->agent_details->name : 'N/A'); ?></td>
                            <td><?php echo e($lead->address_line_one ?? 'N/A'); ?></td>
                            <td><?php echo e($lead->resident_contact ?? 'N/A'); ?></td>
                            <td>
                                <?php switch($lead->status):
                                    case ('draft'): ?><button type="button" class="btn btn-block btn-dark btn-sm">Draft</button><?php break; ?>
                                    <?php case ('pending'): ?><button type="button" class="btn btn-block btn-secondary btn-sm">Lead Submitted</button><?php break; ?>

                                    <?php case ('raBooked'): ?><button type="button" class="btn btn-block btn-primary btn-sm">RA Booked</button><?php break; ?>
                                    <?php case ('installationBooked'): ?><button type="button" class="btn btn-block btn-primary btn-sm">Installation Booked</button><?php break; ?>

                                    <?php case ('installationStarted'): ?><button type="button" class="btn btn-block btn-info btn-sm">Installation Started</button><?php break; ?>
                                    <?php case ('paperworkSubmitted'): ?><button type="button" class="btn btn-block btn-info btn-sm">Funder Paperwork Submitted</button><?php break; ?>

                                    <?php case ('paperworkAccepted'): ?><button type="button" class="btn btn-block btn-warning btn-sm">Awaiting Invoice Payment</button><?php break; ?>
                                    <?php case ('installationCompleted'): ?><button type="button" class="btn btn-block btn-warning btn-sm">Handover Pending</button><?php break; ?>
                                    <?php case ('handoverCompleted'): ?><button type="button" class="btn btn-block btn-warning btn-sm">Funder Paperwork Pending</button><?php break; ?>
                                    <?php case ('raLodged'): ?><button type="button" class="btn btn-block btn-warning btn-sm">Awaiting Installation</button><?php break; ?>
                                    <?php case ('raCompleted'): ?><button type="button" class="btn btn-block btn-warning btn-sm">RA Lodgement Pending</button><?php break; ?>
                                    <?php case ('approved'): ?><button type="button" class="btn btn-block btn-warning btn-sm">RA Pending</button><?php break; ?>
                                    <?php case ('onHold'): ?><button type="button" class="btn btn-block btn-warning btn-sm">OnHold</button><?php break; ?>

                                    <?php case ('paperworkError'): ?><button type="button" class="btn btn-block btn-danger btn-sm">Funder Paperwork Error</button><?php break; ?>
                                    <?php case ('rejected'): ?><button type="button" class="btn btn-block btn-danger btn-sm">Rejected</button><?php break; ?>
                                    <?php case ('invoicePaid'): ?><button type="button" class="btn btn-block btn-success btn-sm">Invoice Paid</button><?php break; ?>
                                <?php endswitch; ?>
                            </td>
                            <td><?php echo e($lead->created_at->format('Y-m-d H:i')); ?></td>
                            <td class="text-center">
                                <form method="post" id="delete-form" action="<?php echo e(route('leads.destroy', $lead->id)); ?>">
                                    <?php if(auth()->user()->role == 'admin' || $lead->status == 'draft'): ?>
                                        <a href="<?php echo e(route('leads.edit', $lead->id)); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-pen"></i></a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="SingleDelete btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                    <?php endif; ?>
                                    <?php if(!in_array($lead->status,['draft','rejected','onHold']) && auth()->user()->role == 'admin'): ?>
                                        <a href="<?php echo e(route('leads.details', ['data-matched',$lead->id])); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-book-open"></i></a>
                                        <a href="<?php echo e(route('leads.details', ['retrofit',$lead->id])); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-user-cog"></i></a>
                                        <a href="<?php echo e(route('leads.details', ['measure-install',$lead->id])); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-ruler-combined"></i></a>
                                        <a href="<?php echo e(route('leads.details', ['handover',$lead->id])); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-hand-holding"></i></a>
                                        <a href="<?php echo e(route('leads.details', ['summary',$lead->id])); ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-calculator"></i></a>
                                    <?php endif; ?>
                                    <?php if($lead->status == 'completed'): ?>
                                        <a href="<?php echo e(route('survey.pdf', $lead->id)); ?>" class="btn btn-sm btn-outline-secondary"><i class="fas fa-file-pdf"></i></a>
                                    <?php endif; ?>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr style="width: 100%">No Records Found!</tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
                <div class="card-footer clearfix ">
                    <?php echo e($leads->links('pagination.links')); ?>

                </div>
            </div>
            <!-- /.card -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Leads-app-laravel\resources\views/leads/index.blade.php ENDPATH**/ ?>