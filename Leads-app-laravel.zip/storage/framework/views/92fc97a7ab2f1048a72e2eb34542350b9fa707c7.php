<?php $__env->startSection('title', 'Handover & Submission'); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="card card-primary">
        <!-- form start -->
        <form method="POST" action="<?php echo e(route('leads.handover', request('lead')->id)); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-3">
                        <div class="form-group">
                            <label for="handover_on">Handover Date</label>
                            <input value="<?php echo e(isset($lead) && $lead->details ? $lead->details->handover_on :old('handover_on')); ?>" type="date" class="form-control <?php $__errorArgs = ['handover_on'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="handover_on" id="handover_on" placeholder="Enter Handover date">
                            <?php $__errorArgs = ['handover_on'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="handover_on" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="is_handover_emailed">Handover Emailed</label>
                            <select class="form-control <?php $__errorArgs = ['is_handover_emailed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_handover_emailed" name="is_handover_emailed" style="width: 100%;">
                                <option value="false" <?php echo e(isset($lead->details) && !$lead->details->is_handover_emailed ? 'selected' : (old('is_handover_emailed') == 'false' ? 'selected': '')); ?>>No</option>
                                <option value="true" <?php echo e(isset($lead->details) && $lead->details->is_andover_emailed ? 'selected' : (old('is_handover_emailed') ? 'selected': '')); ?>>Yes</option>
                            </select>
                            <?php $__errorArgs = ['is_handover_emailed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="is_handover_emailed" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="is_warranty_applied">Warranties Applied</label>
                            <select class="form-control <?php $__errorArgs = ['is_warranty_applied'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_warranty_applied" name="is_warranty_applied" style="width: 100%;">
                                <option value="true" <?php echo e(isset($lead->details) && $lead->details->is_warranty_applied ? 'selected' : (old('is_warranty_applied') == 'true' ? 'selected': '')); ?>>Yes</option>
                                <option value="false" <?php echo e(isset($lead->details) && !$lead->details->is_warranty_applied ? 'selected' : (old('is_warranty_applied') == 'false' ? 'selected': '')); ?>>No</option>
                            </select>
                            <?php $__errorArgs = ['is_warranty_applied'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="is_warranty_applied" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="status">Funder Paper Work</label>
                            <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status" style="width: 100%;">
                                <option value="">Pending</option>
                                <option value="paperworkSubmitted" <?php echo e(isset($lead) && $lead->status == 'paperworkSubmitted' ? 'selected' : (old('status') == 'paperworkSubmitted' ? 'selected': '')); ?>>Submitted</option>
                                <option value="paperworkError" <?php echo e(isset($lead) && $lead->status == 'paperworkError' ? 'selected' : (old('status') == 'paperworkError' ? 'selected': '')); ?>>Error</option>
                                <option value="paperworkAccepted" <?php echo e(isset($lead) && $lead->status == 'paperworkAccepted' ? 'selected' : (old('status') == 'paperworkAccepted' ? 'selected': '')); ?>>Accepted</option>
                            </select>
                            <?php $__errorArgs = ['is_completed_submission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="is_completed_submission" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-3">
                        <div class="form-group">
                            <label for="is_invoice_paid">Invoice Paid</label>
                            <select class="form-control <?php $__errorArgs = ['is_invoice_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_invoice_paid" name="is_invoice_paid" style="width: 100%;">
                                <option value="false" <?php echo e(isset($lead->details) && !$lead->details->is_invoice_paid ? 'selected' : (old('is_invoice_paid') == 'false' ? 'selected': '')); ?>>No</option>
                                <option value="true" <?php echo e(isset($lead->details) && $lead->details->is_invoice_paid ? 'selected' : (old('is_invoice_paid') ? 'selected': '')); ?>>Yes</option>
                            </select>
                            <?php $__errorArgs = ['is_invoice_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="is_invoice_paid" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="form-group">
                            <label for="is_agent_paid">Agent Paid</label>
                            <select class="form-control <?php $__errorArgs = ['is_agent_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_agent_paid" name="is_agent_paid" style="width: 100%;">
                                <option value="false" <?php echo e(isset($lead->details) && !$lead->details->is_agent_paid ? 'selected' : (old('is_agent_paid') == 'false' ? 'selected': '')); ?>>No</option>
                                <option value="true" <?php echo e(isset($lead->details) && $lead->details->is_agent_paid ? 'selected' : (old('is_agent_paid') ? 'selected': '')); ?>>Yes</option>
                            </select>
                            <?php $__errorArgs = ['is_agent_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="is_agent_paid" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
                <a href="<?php echo e(route('leads.index')); ?>" class="btn btn-secondary">Back</a>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
    <!-- /.card -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Leads-app-laravel\resources\views/leads/handover.blade.php ENDPATH**/ ?>