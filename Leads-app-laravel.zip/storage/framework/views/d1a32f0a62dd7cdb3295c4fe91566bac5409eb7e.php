<?php $__env->startSection('title', 'Retrofit Assessment / Findings'); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="card card-primary">
        <!-- form start -->
        <form method="POST" action="<?php echo e(route('leads.retrofit', request('lead')->id)); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label for="ra_name">Retrofit Assessor Assigned</label>
                            <input value="<?php echo e(old('ra_name', isset($row) ? $row->ra_name : '')); ?>" type="text" class="form-control <?php $__errorArgs = ['ra_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ra_name" id="ra_name" placeholder="Enter Retrofit Assessor Assigned">
                            <?php $__errorArgs = ['ra_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="ra_name" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="is_rfa_complete">RFA Complete</label>
                            <select class="form-control <?php $__errorArgs = ['is_rfa_complete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_rfa_complete" name="is_rfa_complete" style="width: 100%;">
                                <option value="false" <?php echo e(isset($row) && !$row->is_rfa_complete ? 'selected' : (old('is_rfa_complete') == 'false' ? 'selected': '')); ?>>No</option>
                                <option value="true" <?php echo e(isset($row) && $row->is_rfa_complete ? 'selected' : (old('is_rfa_complete') ? 'selected': '')); ?>>Yes</option>
                            </select>
                            <?php $__errorArgs = ['is_rfa_complete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="is_rfa_complete" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="is_rfa_lodged">RFA Lodgement</label>
                            <select class="form-control <?php $__errorArgs = ['is_rfa_lodged'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_rfa_lodged" name="is_rfa_lodged" style="width: 100%;">
                                <option value="false" <?php echo e(isset($row) && !$row->is_rfa_lodged ? 'selected' : (old('is_rfa_lodged') == 'false' ? 'selected': '')); ?>>No</option>
                                <option value="true" <?php echo e(isset($row) && $row->is_rfa_lodged ? 'selected' : (old('is_rfa_lodged') ? 'selected': '')); ?>>Yes</option>
                            </select>
                            <?php $__errorArgs = ['is_rfa_lodged'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="is_rfa_lodged" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label for="rfa_booked_date">RFA Booked Date</label>
                            <input value="<?php echo e(old('rfa_booked_date', isset($row) ? $row->rfa_booked_date : '')); ?>" type="date" class="form-control <?php $__errorArgs = ['rfa_booked_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rfa_booked_date" id="rfa_booked_date" placeholder="Enter RFA Booked Date">
                            <?php $__errorArgs = ['rfa_booked_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="rfa_booked_date" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="rfa_booked_time">RFA Booked Time</label>
                            <input value="<?php echo e(old('rfa_booked_time', isset($row) ? $row->rfa_booked_time : '')); ?>" type="time" class="form-control <?php $__errorArgs = ['rfa_booked_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rfa_booked_time" id="rfa_booked_time" placeholder="Enter RFA Booked Time">
                            <?php $__errorArgs = ['rfa_booked_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="rfa_booked_time" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="pre_epr_result">Pre EPR Result</label>
                            <input value="<?php echo e(old('pre_epr_result', isset($row) ? $row->pre_epr_result : '')); ?>" type="text" class="form-control <?php $__errorArgs = ['pre_epr_result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pre_epr_result" id="pre_epr_result" placeholder="Enter Pre EPR Result">
                            <?php $__errorArgs = ['pre_epr_result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="pre_epr_result" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label for="post_epr_result">Post EPR Result</label>
                            <input value="<?php echo e(old('post_epr_result', isset($row) ? $row->post_epr_result : '')); ?>" type="text" class="form-control <?php $__errorArgs = ['post_epr_result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="post_epr_result" id="post_epr_result" placeholder="Enter Post EPR Result">
                            <?php $__errorArgs = ['post_epr_result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="post_epr_result" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="floor_area">Floor Area</label>
                            <input value="<?php echo e(old('floor_area', isset($row) ? $row->floor_area : '')); ?>" type="text" class="form-control <?php $__errorArgs = ['floor_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="floor_area" id="floor_area" placeholder="Enter Floor Area">
                            <?php $__errorArgs = ['floor_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="floor_area" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="is_floor_plan_created">Floor Plan Created</label>
                            <select class="form-control <?php $__errorArgs = ['is_floor_plan_created'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="is_floor_plan_created" name="is_floor_plan_created" style="width: 100%;">
                                <option value="false" <?php echo e(isset($row) && !$row->is_floor_plan_created ? 'selected' : (old('is_floor_plan_created') == 'false' ? 'selected': '')); ?>>No</option>
                                <option value="true" <?php echo e(isset($row) && $row->is_floor_plan_created ? 'selected' : (old('is_floor_plan_created') ? 'selected': '')); ?>>Yes</option>
                            </select>
                            <?php $__errorArgs = ['is_floor_plan_created'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="is_floor_plan_created" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="form-group">
                            <label for="rc_name">RC Full Name</label>
                            <input value="<?php echo e(old('rc_name', isset($row) ? $row->rc_name : '')); ?>" type="text" class="form-control <?php $__errorArgs = ['rc_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rc_name" id="rc_name" placeholder="Enter RC Full Name">
                            <?php $__errorArgs = ['rc_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="rc_name" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label for="wall_type">Wall Type</label>
                            <select class="form-control <?php $__errorArgs = ['wall_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="wall_type" name="wall_type" style="width: 100%;">
                                <option value="solid_wall" <?php echo e(isset($row) && $row->wall_type == 'solid_wall' ? 'selected' : (old('wall_type') == 'solid_wall' ? 'selected': '')); ?>>Solid Wall</option>
                                <option value="non_solid_wall" <?php echo e(isset($row) && $row->wall_type == 'non_solid_wall' ? 'selected' : (old('wall_type') == 'non_solid_wall' ? 'selected': '')); ?>>Non Solid Wall</option>
                            </select>
                            <?php $__errorArgs = ['wall_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span id="wall_type" class="error invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
                <a href="<?php echo e(route('leads.index')); ?>" class="btn btn-secondary">Back</a>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
    <!-- /.card -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Leads-app-laravel\resources\views/leads/retrofit-form.blade.php ENDPATH**/ ?>